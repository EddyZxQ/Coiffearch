package com.example.rowcalendarbyeddy.Adaptador

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.rowcalendarbyeddy.R

class RecyclerCalendario(
    private var contexto:Context,
    private var listaDeDias:MutableList<Calendario>,
    private  var itemClickListener:CalendarioClickListener):RecyclerView.Adapter<RecyclerCalendario.HolderCalendario>()
{
    interface CalendarioClickListener{
        fun onCartaClick()
    }

    inner class HolderCalendario(itemView:View):RecyclerView.ViewHolder(itemView){

        var fieldDia: TextView
        var fieldDiaTexto: TextView


        init {

            fieldDia = itemView.findViewById(R.id.fieldDia)
            fieldDiaTexto = itemView.findViewById(R.id.fieldDiaTexto)

        }

        fun bind (position:Int){}

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HolderCalendario {
        val itemView =LayoutInflater.from(contexto).inflate(R.layout.item_calendario, parent,false)
        return HolderCalendario(itemView)
    }

    override fun onBindViewHolder(holder: HolderCalendario, position: Int) {
        val listDias = listaDeDias[position]
        holder.fieldDia.text = listDias.dia
        holder.fieldDiaTexto.text = listDias.diaTexto
        holder.bind(position)

    }

    override fun getItemCount(): Int {
       return listaDeDias.size
    }


}