package com.example.rowcalendarbyeddy.Adaptador

data class Calendario(var dia:String, var mes:String, var ano:String, var diaTexto:String)