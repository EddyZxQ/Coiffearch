package com.example.rowcalendarbyeddy

import android.content.res.Configuration
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.rowcalendarbyeddy.Adaptador.Calendario
import com.example.rowcalendarbyeddy.Adaptador.RecyclerCalendario
import com.example.rowcalendarbyeddy.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.*


class MainActivity : AppCompatActivity(), RecyclerCalendario.CalendarioClickListener {

    private lateinit var binding: ActivityMainBinding
    private lateinit var recycler:RecyclerView

    private var diaMes:MutableList<Calendario> = mutableListOf()


    private var currentFecha:Calendar = Calendar.getInstance(TimeZone.getTimeZone("UTC"))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)

        cambiarIdioma("es")

        //uwu
        setContentView(binding.root)

        var instanciaCalendario = Calendar.getInstance()
        var hoy = instanciaCalendario.toInstant()


/*
        var diasMes = YearMonth.of(2022,1)
        binding.fieldFecha.text = diasMes.lengthOfMonth().toString()


 */

        //Numero de dias que tiene un mes

        var diasDelMes = Calendar.getInstance().getActualMaximum(Calendar.DAY_OF_MONTH).toString()



        binding.fieldFecha.text = Calendar.getInstance().getActualMaximum(Calendar.DAY_OF_MONTH).toString()


        var diadehoy = Calendar.getInstance().get(Calendar.DAY_OF_WEEK)

        var formatoTexto = SimpleDateFormat("EEEE").format(diadehoy)

        binding.fechita.text =formatoTexto



        var diaX = Calendar.getInstance()
        diaX.set(2022,3,9)


       // var day = diaX[5].toString()
       // var month = diaX[2].toString()
       // var year = diaX[1].toString()


        //temita listado de dias

        try {

           var fecha: Calendar

            for (i in 1..Calendar.getInstance().getActualMaximum(Calendar.DAY_OF_MONTH)){
                fecha = GregorianCalendar(currentFecha[1],  (currentFecha[2]+1), i)


                diaMes.add(
                    Calendario(
                        i.toString(),
                        (currentFecha[2]+1).toString(),
                        currentFecha[1].toString(),
                        when(fecha[Calendar.DAY_OF_WEEK]){
                            1 -> "LUNES"
                            2 -> "MARTES"
                            3 -> "MIERCOLES"
                            4 -> "JUEVES"
                            5 -> "VIERNES"
                            6 -> "SABADO"
                            7 -> "DOMINGO"
                            else ->"JAJAXD"
                        }
                    )
                )

            }
            setUp()
        } catch (e: Exception) {
        }





//EXAMPLE CALENDAR

        val sdf = SimpleDateFormat("yyyy MMM dd HH:mm:ss")
        val calendar: Calendar = GregorianCalendar(2013, 1, 31, 13, 24, 56)
        //val calendar: Calendar = GregorianCalendar(2013, 1, 28)

        val year = calendar[Calendar.YEAR]
        val month = calendar[Calendar.MONTH] // Jan = 0, dec = 11

        val dayOfMonth = calendar[Calendar.DAY_OF_MONTH]
        val dayOfWeek = calendar[Calendar.DAY_OF_WEEK]
        val weekOfYear = calendar[Calendar.WEEK_OF_YEAR]
        val weekOfMonth = calendar[Calendar.WEEK_OF_MONTH]

        val hour = calendar[Calendar.HOUR] // 12 hour clock

        val hourOfDay = calendar[Calendar.HOUR_OF_DAY] // 24 hour clock

        val minute = calendar[Calendar.MINUTE]
        val second = calendar[Calendar.SECOND]
        val millisecond = calendar[Calendar.MILLISECOND]


        binding.idioma.text = dayOfWeek.toString()


/*



        var texto = ""

        for (i in 0..16){
            texto += currentFecha[i].toString()+"\n"
        }

        binding.idioma.text = texto


*/


    }

    private  fun cambiarIdioma(idioma:String){
        Locale.setDefault(Locale(idioma))
        val config = Configuration()
        config.setLocale(Locale(idioma))
        baseContext.applicationContext.createConfigurationContext(config)
        baseContext.resources.displayMetrics.setTo( baseContext.resources.displayMetrics)
    }


    private fun setUp(){

        var linear = LinearLayoutManager(this)
        linear.orientation = LinearLayoutManager.HORIZONTAL

        recycler= binding.listaDiasMes
        recycler.layoutManager= linear

        recycler.adapter= RecyclerCalendario(this,diaMes,this)

    }

    override fun onCartaClick() {}


}