package com.example.coiffearch.usuario

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.coiffearch.R
import com.example.coiffearch.citasadptador.Cita
import com.example.coiffearch.citasadptador.RecyclerCitas
import com.example.coiffearch.databinding.ActivityCitasUsuarioBinding
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import java.text.SimpleDateFormat
import java.util.*

class CitasUsuarioActivity : AppCompatActivity(),RecyclerCitas.OnItemRecyclerClickListener {

    private  lateinit var  binding: ActivityCitasUsuarioBinding
    var db = Firebase.firestore
    lateinit var  recycler:RecyclerView
    var listaCitas: MutableList<Cita> = mutableListOf()
    var idUser = Firebase.auth.currentUser?.uid.toString()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCitasUsuarioBinding.inflate(layoutInflater)
        setContentView(binding.root)


        db.collection("citas").get().addOnSuccessListener { resultado ->
            for (documento in resultado){

                if (documento.data["userId"] == idUser){

                    listaCitas.add(Cita(
                        documento.data["accion"].toString(),
                        documento.data["fechahora"].toString(),
                        documento.data["citaId"].toString()
                    ))

                }


            }

            setUp()
        }


        binding.btnAtrasC.setOnClickListener { irMain() }




    }


    private fun setUp(){
        recycler = findViewById(R.id.listaCitas)
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = RecyclerCitas(this, listaCitas,this)
    }

    fun irMain(){
        startActivity(Intent(this, PanelUsuarioActivity::class.java))
        finish()
    }



    override fun onBackPressed() { irMain() }

    @SuppressLint("NotifyDataSetChanged")
    override fun onItemClick(idCita: String) {
        db.collection("citas").document(idCita).delete()
        finish()
        startActivity(intent)
    }
}