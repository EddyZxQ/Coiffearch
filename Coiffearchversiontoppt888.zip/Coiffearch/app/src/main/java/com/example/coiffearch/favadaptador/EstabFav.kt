package com.example.coiffearch.favadaptador

data class EstabFav (var idEstab:String,
                     var nombreEstab:String,
                     var estado:String,
                     var lugar:String,
                     var horario:String,
                     var url:String )