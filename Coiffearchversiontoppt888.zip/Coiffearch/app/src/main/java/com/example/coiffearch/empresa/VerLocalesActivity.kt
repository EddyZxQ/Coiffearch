package com.example.coiffearch.empresa

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.coiffearch.R
import com.example.coiffearch.adaptadorlocales.Local
import com.example.coiffearch.adaptadorlocales.RecyclerLocal
import com.example.coiffearch.databinding.ActivityPanelEmpresaBinding
import com.example.coiffearch.databinding.ActivityVerLocalesBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class VerLocalesActivity : AppCompatActivity(), RecyclerLocal.OnBotonesClickListener2 {

    private  lateinit var binding: ActivityVerLocalesBinding
    private lateinit var auth: FirebaseAuth
    lateinit var recycler: RecyclerView
    private var listaLocales = mutableListOf<Local>()
    var db = Firebase.firestore


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityVerLocalesBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = Firebase.auth

        binding.btnAgregarLocal.setOnClickListener {
            startActivity(Intent(this@VerLocalesActivity, AgregarEstablecimientoActivity::class.java))
            finish()
        }

        binding.btnAtrasPU.setOnClickListener { irAtras() }

        obtenerEstablecimiento()
    }



    private fun obtenerEstablecimiento(){
        db.collection("establecimiento").get().addOnSuccessListener { documentos ->

            for (documento in documentos){
                   if (documento.data["idPropietario"].toString() == auth.currentUser?.uid.toString()){
                    listaLocales.add(
                        Local(
                            documento.data["establecimientoId"].toString(),
                            documento.data["nombre"].toString(),
                            documento.data["imagenesExposicion"] as MutableList<String>
                        )
                    )

                }
            }

            setUp()
        }
    }

    fun setUp(){
        recycler= findViewById(R.id.listaLocales)
        recycler.layoutManager= LinearLayoutManager(this)
        recycler.adapter= RecyclerLocal(this,listaLocales,this)

    }

    override fun onEliminarClick(idEstab: String) {
      db.collection("establecimiento").document(idEstab).delete()

        for (i in 0 until  listaLocales.size -1){
            if (listaLocales[i].id == idEstab){
                listaLocales.removeAt(i)
            }
        }

        setUp()

    }

    override fun onCartaClick(idEstab: String) {
        //no darle
    }

    private fun irAtras(){
        startActivity(Intent(this@VerLocalesActivity, PanelEmpresaActivity::class.java))
        finish()
    }
}