package com.example.coiffearch

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.coiffearch.databinding.ActivityRegisterBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.ktx.storage
import java.util.*

class RegisterActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRegisterBinding

    private lateinit var auth: FirebaseAuth

    private val db = Firebase.firestore


    lateinit var campoEmail:String
    lateinit var campoPass:String
    lateinit var campoRepitePass:String
    lateinit var campoNombre:String
    lateinit var campoApellidos:String
    lateinit var campoUsuario:String
    var campotipoCuenta:Int = -1
    lateinit var storage: FirebaseStorage

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        this.supportActionBar?.hide()


        auth = Firebase.auth
        storage = Firebase.storage

        binding.btnRegistrarse.setOnClickListener {

            campoEmail =binding.camporREmail.text.toString()
            campoPass = binding.campoRPass.text.toString()
            campoRepitePass = binding.campoRRepitePass.text.toString()
            campoNombre = binding.campoRNombre.text.toString()
            campoUsuario = binding.campoRUsuario.text.toString()
            campoApellidos = binding.campoRApellidos.text.toString()

            if (campoEmail.isNotEmpty() && campoApellidos.isNotEmpty() &&
                campoNombre.isNotEmpty() && campoUsuario.isNotEmpty() &&
                campoPass.isNotEmpty() && campoRepitePass.isNotEmpty() &&
                (binding.radioEmpresa.isChecked || binding.radioUsuario.isChecked)){

                if (campoEmail.contains("@") && campoEmail.contains(".")){

                    if (campoPass.length in 6..16){
                        if (campoPass == campoRepitePass){

                            registrar(campoEmail,campoPass)

                        }else{
                            Toast.makeText(this,"Las contraseñas no coninciden",Toast.LENGTH_SHORT).show()
                        }
                    }else{
                        Toast.makeText(this,"La contraseña debe tener entre 6 y 16 caracteres",Toast.LENGTH_SHORT).show()
                    }

                }else{
                    Toast.makeText(this,"Debes introducir un email correcto",Toast.LENGTH_SHORT).show()
                }

            }else{
                Toast.makeText(this,"Debes rellenar todos los campos",Toast.LENGTH_SHORT).show()
            }

        }


        binding.tengoCuenta.setOnClickListener {
            startActivity(Intent(this@RegisterActivity,LoginActivity::class.java))
            finish()
        }


    }


    private fun registrar(email:String, pass:String){
        auth.createUserWithEmailAndPassword(email, pass)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {

                    campoEmail =binding.camporREmail.text.toString()
                    campoPass = binding.campoRPass.text.toString()
                    campoRepitePass = binding.campoRRepitePass.text.toString()
                    campoNombre = binding.campoRNombre.text.toString()
                    campoUsuario = binding.campoRUsuario.text.toString()
                    campoApellidos = binding.campoRApellidos.text.toString()
                    if (binding.radioUsuario.isChecked)
                        campotipoCuenta = 0
                    else if(binding.radioEmpresa.isChecked){
                        campotipoCuenta = 1
                    }


                    registrarInfoUsuario(campoEmail,campoUsuario,campoNombre,campoApellidos,campotipoCuenta)
                    Toast.makeText(this,"La cuenta se ha creado correctamente",Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this,"Error al crear la cuenta",Toast.LENGTH_SHORT).show()
                }

            }

    }

    private fun registrarInfoUsuario(email:String, usuarion:String, nombre:String, apellidos:String, tipoCuenta:Int){

        val storage = Firebase.storage("gs://coiffearch.appspot.com")

        storage.reference.child("defaultImg.png").downloadUrl.addOnSuccessListener {
           it.toString()
            Toast.makeText(this,it.toString(), Toast.LENGTH_LONG).show()


            val usuario = mapOf(
                "id" to auth.currentUser?.uid.toString(),
                "email" to email,
                "usuario" to usuarion,
                "nombre" to nombre,
                "apellidos" to apellidos,
                "tipoCuenta" to tipoCuenta,
                "estFavoritos" to listOf<String>(),
                "imgPerfil" to "${ it.toString()}"

            )
            db.collection("usuarios").document(auth.currentUser?.uid.toString()).set(usuario)
            startActivity(Intent(this@RegisterActivity,LoginActivity::class.java))
        }

    }


}