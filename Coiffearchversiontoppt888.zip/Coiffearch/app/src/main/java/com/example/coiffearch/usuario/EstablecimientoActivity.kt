package com.example.coiffearch.usuario

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.DatePicker
import android.widget.TimePicker
import android.widget.Toast
import com.example.coiffearch.R
import com.example.coiffearch.databinding.ActivityEstablecimientoBinding
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.google.firestore.v1.ArrayValue
import java.text.SimpleDateFormat
import java.time.Instant
import java.util.*

class EstablecimientoActivity : AppCompatActivity(), DatePickerDialog.OnDateSetListener, TimePickerDialog.OnTimeSetListener {

    private lateinit var binding: ActivityEstablecimientoBinding
    private var db = Firebase.firestore
    private lateinit var auth: FirebaseAuth

    var dia = 0
    var mes = 0
    var ano = 0
    var hora = 0
    var minuto = 0

    var guardarDia = 0
    var guardarMes = 0
    var guardarAno = 0
    var guardarHora = 0
    var guardarMinuto = 0

    var listaServicios:MutableList<String> = mutableListOf()



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEstablecimientoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        listaServicios()
        comprobarFav()


        auth = Firebase.auth

        var intento = intent

        db.collection("establecimiento").document(intento.getStringExtra("idEstablecimiento").toString())
            .get()
            .addOnSuccessListener { documento ->

                binding.campoTituloE.text = documento["nombre"].toString()
                binding.campoDescripcionE.text = documento["descripcion"].toString()
                binding.campoEstadoE.text = if (documento["estaAbierto"] as Boolean)"Abierto" else "Cerrado"
                binding.campoHorarioE.text = documento["aperturaHora"].toString()+"/"+documento["cierreHora"].toString()
                binding.campoPublicoE.text = documento["publico"].toString()
                binding.campoUbicacionE.text = documento["ubicacion"].toString()

            }


        binding.btnAtrasE.setOnClickListener {
            startActivity(Intent(this@EstablecimientoActivity, BusquedaUsuarioActivity::class.java))
            finish()
        }

        escogerFecha()


        binding.btnPedirCita.setOnClickListener {  establecerCita() }

        binding.btnAgregarFav.setOnClickListener {

            if (binding.btnAgregarFav.isChecked){
                db.collection("usuarios").document(auth.currentUser?.uid.toString())
                    .update("estFavoritos", FieldValue.arrayUnion(intent.getStringExtra("idEstablecimiento")))
            }else{
                db.collection("usuarios").document(auth.currentUser?.uid.toString())
                    .update("estFavoritos", FieldValue.arrayRemove(intent.getStringExtra("idEstablecimiento")))
            }
        }





    }


    private fun listaServicios(){

        db.collection("establecimiento")
            .document(intent.getStringExtra("idEstablecimiento").toString()).get()
            .addOnSuccessListener { documento ->
                listaServicios.addAll(documento["servicio"] as ArrayList<String>)
                val arrayAdapter = ArrayAdapter(this,R.layout.lista_item, listaServicios)
                binding.autoCompleteTextCView.setAdapter(arrayAdapter)
        }

    }

    private fun comprobarFav(){
        auth = Firebase.auth

        db.collection("usuarios")
          .document(auth.currentUser?.uid.toString())
          .get()
          .addOnSuccessListener { resultado ->
              binding.btnAgregarFav.isChecked = (resultado["estFavoritos"] as MutableList<String>).contains(intent.getStringExtra("idEstablecimiento"))
                //fallo aqui

          }



    }


    private fun getDateTimeCalendar(){
        val cal = Calendar.getInstance()
        dia = cal.get(Calendar.DAY_OF_MONTH)
        mes = cal.get(Calendar.MONTH)
        ano = cal.get(Calendar.YEAR)
        hora = cal.get(Calendar.HOUR)
        minuto = cal.get(Calendar.MINUTE)
    }


    private fun escogerFecha(){
        binding.btnEscoger.setOnClickListener {
            getDateTimeCalendar()

            DatePickerDialog(this,this,ano,mes,dia).show()
        }
    }

    override fun onDateSet(view: DatePicker?, ano: Int, mes: Int, diames: Int) {
         guardarDia = diames
         guardarMes = mes
         guardarAno = ano

        getDateTimeCalendar()

        TimePickerDialog(this,this,hora,minuto, true).show()

    }

    override fun onTimeSet(view: TimePicker?, hora: Int, minuto: Int) {
        guardarHora =  hora
        guardarMinuto = minuto

        binding.diahora.text = "FECHA SELECCIONADA: $guardarDia/$guardarMes/$guardarAno  $guardarHora:$guardarMinuto"
    }


    private fun establecerCita(){

        var intento = intent

        var id = UUID.randomUUID()

        db.collection("citas").document(id.toString())
            .set(mapOf(
                "accion" to binding.autoCompleteTextCView.text.toString(),
                "citaId" to id.toString(),
                "establecimientoId" to intento.getStringExtra("idEstablecimiento").toString(),
                "fechahora" to "$guardarDia/$guardarMes/$guardarAno  $guardarHora:$guardarMinuto",
                "userId" to auth.currentUser?.uid
            ))

    }


    fun irBusqueda(){
        startActivity(Intent(this, BusquedaUsuarioActivity::class.java))
        finish()
    }


    override fun onBackPressed() {
        irBusqueda()
    }
}