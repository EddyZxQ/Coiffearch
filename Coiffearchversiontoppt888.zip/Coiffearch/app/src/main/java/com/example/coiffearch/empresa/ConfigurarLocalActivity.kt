package com.example.coiffearch.empresa

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.coiffearch.databinding.ActivityConfigurarLocalBinding

class ConfigurarLocalActivity : AppCompatActivity() {

    private lateinit var binding: ActivityConfigurarLocalBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityConfigurarLocalBinding.inflate(layoutInflater)
        setContentView(binding.root)



    }
}