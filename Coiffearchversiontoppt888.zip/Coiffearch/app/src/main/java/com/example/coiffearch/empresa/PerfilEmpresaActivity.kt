package com.example.coiffearch.empresa

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import com.bumptech.glide.Glide
import com.example.coiffearch.LoginActivity
import com.example.coiffearch.R
import com.example.coiffearch.databinding.ActivityPerfilEmpresaBinding
import com.example.coiffearch.databinding.ActivityPerfilUsuarioBinding
import com.example.coiffearch.usuario.PanelUsuarioActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class PerfilEmpresaActivity : AppCompatActivity() {

    private lateinit var binding:ActivityPerfilEmpresaBinding
    private  var db = Firebase.firestore
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPerfilEmpresaBinding.inflate(layoutInflater)
        setContentView(binding.root)
        auth = Firebase.auth
        getInfoUsuario()


        binding.btnEditarE.setOnClickListener {
            binding.btnEditarE.visibility = View.GONE
            binding.contenedorBtnEditarE.visibility = View.VISIBLE
            binding.cEmailE.isEnabled = true
            binding.cNombreE.isEnabled = true
            binding.cApellidoE.isEnabled = true
        }

        binding.btnCancelarE.setOnClickListener {
            binding.contenedorBtnEditarE.visibility = View.GONE
            binding.btnEditarE.visibility = View.VISIBLE
            binding.cEmailE.isEnabled = false
            binding.cNombreE.isEnabled = false
            binding.cApellidoE.isEnabled = false
        }


        binding.btnGuardarE.setOnClickListener {
            binding.contenedorBtnEditarE.visibility = View.GONE
            binding.btnEditarE.visibility = View.VISIBLE
            binding.cEmailE.isEnabled = false
            binding.cNombreE.isEnabled = false
            binding.cApellidoE.isEnabled = false
            db.collection("usuarios")
                .document(auth.currentUser?.uid.toString())
                .update(
                    "email", binding.cEmailE.text.toString(),
                    "nombre", binding.cNombreE.text.toString(),
                    "apellidos", binding.cApellidoE.text.toString())

            auth.currentUser!!.updateEmail(binding.cEmailE.text.toString()).addOnCompleteListener {

            }

        }

        binding.btnEliminarCuentaE.setOnClickListener {
            db.collection("usuarios").document(auth.currentUser?.uid.toString())
                .delete()
                .addOnSuccessListener { Toast.makeText(this, "Cuenta eliminada con exito", Toast.LENGTH_SHORT).show() }
                .addOnFailureListener { Toast.makeText(this, "Error al eliminar la cuenta", Toast.LENGTH_SHORT).show() }

            auth.currentUser?.delete()

            startActivity(Intent(this@PerfilEmpresaActivity, LoginActivity::class.java))
            finish()

        }

        binding.btnAtrasPE.setOnClickListener { irAtras() }

        binding.btnCerrarSesionPerfilUserE.setOnClickListener {
            Firebase.auth.signOut()
            startActivity(Intent(this@PerfilEmpresaActivity, LoginActivity::class.java))
            finish()
        }
    }


    private fun getInfoUsuario(){
        db.collection("usuarios")
            .document(auth.currentUser?.uid.toString())
            .get()
            .addOnSuccessListener {
                if (it.exists()) {
                    binding.cUsuarioPE.text = it.get("usuario").toString()
                    binding.cNombreE.setText(it.get("nombre").toString())
                    binding.cApellidoE.setText(it.get("apellidos").toString())
                    binding.cEmailE.setText(it.get("email").toString())


                    Glide.with(this).load(it.get("imgPerfil")).into(binding.fotoPerfilE)
                }
            }
    }

    private fun irAtras(){
        startActivity(Intent(this@PerfilEmpresaActivity, PanelEmpresaActivity::class.java ))
        finish()
    }


    override fun onBackPressed() { irAtras() }

}