package com.example.coiffearch.establecimientoadaptador

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.coiffearch.R

class RecyclerEstablecimientos(
    private var context: Context,
    var establecimientos: MutableList<Establecimiento>,
    private var itemClickListener:OnCajaClickListener
    ):RecyclerView.Adapter<RecyclerEstablecimientos.MiHolder> (){


    interface OnCajaClickListener{
        fun onItemClick(idEstab:String)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MiHolder {
       var itemView = LayoutInflater.from(context).inflate(R.layout.item_establecimiento, parent, false)
        return  MiHolder(itemView)
    }

    override fun onBindViewHolder(holder: MiHolder, position: Int) {
        var establecimiento = establecimientos[position]
        holder.campoNombre.text = establecimiento.nombre
        holder.campoUbicacion.text = establecimiento.ubicacion
        holder.campoHorario.text = establecimiento.horario
        holder.campoEstado.text = establecimiento.estado

        holder.bind(position)
    }

    override fun getItemCount(): Int {
        return  establecimientos.size
    }

    inner class MiHolder(itemView: View):RecyclerView.ViewHolder(itemView){
        fun bind(position: Int) {
            itemView.setOnClickListener {
                itemClickListener.onItemClick(establecimientos[position].idEstablecimiento)
            }
        }


        var campoNombre: TextView
        var campoUbicacion: TextView
        var campoHorario: TextView
        var campoEstado: TextView


        init {
            campoNombre = itemView.findViewById(R.id.campoTitulo)
            campoUbicacion = itemView.findViewById(R.id.campoUbicacion)
            campoHorario = itemView.findViewById(R.id.campoHorario)
            campoEstado = itemView.findViewById(R.id.campoEstado)



        }


    }


}