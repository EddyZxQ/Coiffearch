package com.example.coiffearch.establecimientoadaptador

data class Establecimiento (var nombre:String,
                            var ubicacion:String,
                            var horario:String,
                            var estado:String,
                            var idEstablecimiento:String)
