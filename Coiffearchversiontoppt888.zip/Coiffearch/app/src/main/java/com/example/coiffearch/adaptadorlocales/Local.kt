package com.example.coiffearch.adaptadorlocales

data class Local(var id:String, var nombreLocal:String, var imgUrl:MutableList<String>)