package com.example.coiffearch.empresa

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.coiffearch.R
import com.example.coiffearch.adaptadorlocales.Local
import com.example.coiffearch.adaptadorlocales.RecyclerLocal
import com.example.coiffearch.databinding.ActivityPanelEmpresaBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class PanelEmpresaActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPanelEmpresaBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPanelEmpresaBinding.inflate(layoutInflater)
        setContentView(binding.root)



        binding.btnPerfilE.setOnClickListener {
            startActivity(Intent(this@PanelEmpresaActivity, PerfilEmpresaActivity::class.java))
            finish()
        }

        binding.btnPanelAdministracion.setOnClickListener {
            startActivity(Intent(this@PanelEmpresaActivity, VerLocalesActivity::class.java))
            finish()
        }



    }


}