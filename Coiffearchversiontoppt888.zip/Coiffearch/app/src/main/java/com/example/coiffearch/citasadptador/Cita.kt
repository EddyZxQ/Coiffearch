package com.example.coiffearch.citasadptador

import java.util.*

data class Cita(var accion:String, var fechahora: String, var id:String)