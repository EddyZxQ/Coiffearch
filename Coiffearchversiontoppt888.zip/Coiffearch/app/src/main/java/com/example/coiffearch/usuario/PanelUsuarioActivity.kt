package com.example.coiffearch.usuario

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageButton
import android.widget.Toast
import com.example.coiffearch.LoginActivity
import com.example.coiffearch.databinding.ActivityPanelUsuarioBinding
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

class PanelUsuarioActivity : AppCompatActivity() {
    private lateinit var  binding: ActivityPanelUsuarioBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPanelUsuarioBinding.inflate(layoutInflater)
        setContentView(binding.root)


        binding.btnFavoritos.setOnClickListener {
            startActivity(Intent(this@PanelUsuarioActivity, FavoritosUsuarioActivity::class.java))
            finish()
        }

        binding.btnNotificaciones.setOnClickListener {
            startActivity(Intent(this@PanelUsuarioActivity, CitasUsuarioActivity::class.java))
            finish()
        }

        binding.btnBusqueda.setOnClickListener {

            startActivity(Intent(this@PanelUsuarioActivity, BusquedaUsuarioActivity::class.java))
            finish()
        }

        binding.btnPerfil.setOnClickListener {
            startActivity(Intent(this@PanelUsuarioActivity, PerfilUsuarioActivity::class.java))
            finish()
        }
    }

    override fun onBackPressed(){ }



}