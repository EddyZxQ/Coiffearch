package com.example.coiffearch.citasadptador

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.example.coiffearch.R
import com.example.coiffearch.establecimientoadaptador.RecyclerEstablecimientos
import com.example.coiffearch.usuario.CitasUsuarioActivity

class RecyclerCitas(private val context: Context, val citas:MutableList<Cita>, private var itemClickListener: OnItemRecyclerClickListener):RecyclerView.Adapter<RecyclerCitas.MiHolder>() {

    interface OnItemRecyclerClickListener{
        fun onItemClick(idCita:String)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerCitas.MiHolder {
        var itemView = LayoutInflater.from(context).inflate(R.layout.item_cita, parent, false)
        return MiHolder(itemView)
    }

    override fun onBindViewHolder(holder: RecyclerCitas.MiHolder, position: Int) {
        var cita =citas[position]
        holder.campoAccion.text = cita.accion
        holder.campoHora.text = cita.fechahora
        holder.bind(position)
    }

    override fun getItemCount(): Int {
        return citas.size
    }

    inner class MiHolder(itemView: View):RecyclerView.ViewHolder(itemView){


        var campoAccion:TextView
        var campoHora:TextView
        var btnEliminar: ImageButton
        lateinit var id:String


        fun bind(position: Int) {
            btnEliminar = itemView.findViewById(R.id.btnEliminar)

            btnEliminar.setOnClickListener {
                itemClickListener.onItemClick(citas[position].id)
            }
        }

        init {
            campoAccion = itemView.findViewById(R.id.campoAccion)
            campoHora = itemView.findViewById(R.id.campoFechaHora)
            btnEliminar = itemView.findViewById(R.id.btnEliminar)

           // btnEliminar.setOnClickListener { Toast.makeText(context, "$campoAccion", Toast.LENGTH_LONG).show() }

        }


    }


}