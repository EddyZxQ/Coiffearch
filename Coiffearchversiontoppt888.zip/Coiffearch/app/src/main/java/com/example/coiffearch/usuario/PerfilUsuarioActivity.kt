package com.example.coiffearch.usuario

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.bumptech.glide.Glide
import com.example.coiffearch.LoginActivity
import com.example.coiffearch.databinding.ActivityPerfilUsuarioBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class PerfilUsuarioActivity : AppCompatActivity() {

    private lateinit var  binding: ActivityPerfilUsuarioBinding
    private  var db = Firebase.firestore
    private lateinit var auth: FirebaseAuth



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPerfilUsuarioBinding.inflate(layoutInflater)
        setContentView(binding.root)
        auth = Firebase.auth
        getInfoUsuario()


        binding.btnEditar.setOnClickListener {
            binding.btnEditar.visibility = View.GONE
            binding.contenedorBtnEditar.visibility = View.VISIBLE
            binding.cEmail.isEnabled = true
            binding.cNombre.isEnabled = true
            binding.cApellido.isEnabled = true
        }

        binding.btnCancelar.setOnClickListener {
            binding.contenedorBtnEditar.visibility = View.GONE
            binding.btnEditar.visibility = View.VISIBLE
            binding.cEmail.isEnabled = false
            binding.cNombre.isEnabled = false
            binding.cApellido.isEnabled = false
        }


        binding.btnGuardar.setOnClickListener {
            binding.contenedorBtnEditar.visibility = View.GONE
            binding.btnEditar.visibility = View.VISIBLE
            binding.cEmail.isEnabled = false
            binding.cNombre.isEnabled = false
            binding.cApellido.isEnabled = false
            db.collection("usuarios")
                .document(auth.currentUser?.uid.toString())
                .update(
                    "email", binding.cEmail.text.toString(),
                "nombre", binding.cNombre.text.toString(),
                "apellidos", binding.cApellido.text.toString())

            auth.currentUser!!.updateEmail(binding.cEmail.text.toString()).addOnCompleteListener {

            }

        }

        binding.btnEliminarCuenta.setOnClickListener {
            db.collection("usuarios").document(auth.currentUser?.uid.toString())
                .delete()
                .addOnSuccessListener { Toast.makeText(this, "Cuenta eliminada con exito", Toast.LENGTH_SHORT).show() }
                .addOnFailureListener { Toast.makeText(this, "Error al eliminar la cuenta", Toast.LENGTH_SHORT).show() }

            auth.currentUser?.delete()

            startActivity(Intent(this@PerfilUsuarioActivity, LoginActivity::class.java))
            finish()

        }

        binding.btnAtrasPU.setOnClickListener { irAtras() }

        binding.btnCerrarSesionPerfilUser.setOnClickListener {
            Firebase.auth.signOut()
            startActivity(Intent(this@PerfilUsuarioActivity, LoginActivity::class.java))
            finish()
        }

    }



    private fun getInfoUsuario(){
        db.collection("usuarios")
            .document(auth.currentUser?.uid.toString())
            .get()
            .addOnSuccessListener {
                if (it.exists()) {
                    binding.cUsuarioPU.text = it.get("usuario").toString()
                    binding.cNombre.setText(it.get("nombre").toString())
                    binding.cApellido.setText(it.get("apellidos").toString())
                    binding.cEmail.setText(it.get("email").toString())


                    Glide.with(this).load(it.get("imgPerfil")).into(binding.fotoPerfil)
                }
            }
    }




    /*
    private fun popUpDatos(position: Int){

        val builder = AlertDialog.Builder(requireActivity())
        val vistaAlerta= layoutInflater.inflate(R.layout.alerta_custom,null)

        builder.setView(vistaAlerta)
        builder.setNeutralButton("Cerrar", null)
        val dialog = builder.create()
        dialog.show()

        var campoUsuario =vistaAlerta.findViewById<View>(R.id.campoUsuarioC) as TextView
        var campoPass =vistaAlerta.findViewById<View>(R.id.campoPassC) as TextView

        campoUsuario.text = usuarios[position]
        campoPass.text = passwords[position]

        vistaAlerta.findViewById<View>(R.id.btnCopiarPass).setOnClickListener { btnCopiar(campoPass.text.toString())}
        vistaAlerta.findViewById<View>(R.id.btnCopiarUsuario).setOnClickListener { btnCopiar(campoUsuario.text.toString())}

    }

    */

    private fun irAtras(){
        startActivity(Intent(this@PerfilUsuarioActivity, PanelUsuarioActivity::class.java ))
        finish()
    }


    override fun onBackPressed() { irAtras() }

}