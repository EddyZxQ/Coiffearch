package com.example.coiffearch.usuario

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.coiffearch.R
import com.example.coiffearch.databinding.ActivityFavoritosUsuarioBinding
import com.example.coiffearch.establecimientoadaptador.Establecimiento
import com.example.coiffearch.establecimientoadaptador.RecyclerEstablecimientos
import com.example.coiffearch.favadaptador.EstabFav
import com.example.coiffearch.favadaptador.RecyclerFav
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class FavoritosUsuarioActivity : AppCompatActivity(), RecyclerFav.OnBotonesClickListener {

    lateinit var  recycler: RecyclerView
    var listaEstablecimientos: MutableList<EstabFav> = mutableListOf()
    private var db = Firebase.firestore
    private  var auth = Firebase.auth


    private lateinit var binding: ActivityFavoritosUsuarioBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFavoritosUsuarioBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnAtrasF.setOnClickListener {
            startActivity(Intent(this@FavoritosUsuarioActivity, PanelUsuarioActivity::class.java))
            finish()
        }




        db.collection("usuarios").document(auth.currentUser?.uid.toString()).get()
            .addOnSuccessListener { campos->
                for (i in campos["estFavoritos"] as MutableList<String>){ cargarDocumento(i) }
            }


    }


    private fun setUp(){
        recycler = findViewById(R.id.listaFavoritos)
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = RecyclerFav(this, listaEstablecimientos, this)
    }


    private fun cargarDocumento(id:String){

        db.collection("establecimiento").document(id).get()
            .addOnSuccessListener { documento ->
                listaEstablecimientos.add(
                    EstabFav(
                        documento["establecimientoId"].toString(),
                        documento["nombre"].toString(),
                        if (documento["estaAbierto"] as Boolean)"Abierto" else "Cerrado",
                        documento["ubicacion"].toString(),
                        documento["aperturaHora"].toString()+"/"+documento["cierreHora"].toString(),
                        "aqui va una url"

                    )
                )
                setUp()
            }

    }

    override fun onBackPressed() {
        startActivity(Intent(this@FavoritosUsuarioActivity, PanelUsuarioActivity::class.java))
        finish()
    }

    override fun onEliminarClick(idEstab: String) {
       db.collection("usuarios").document(auth.currentUser?.uid.toString()).update("estFavoritos" , FieldValue.arrayRemove(idEstab))
       finish()
       startActivity(intent)

    }

    override fun onCartaClick(idCasa: String) {}
}