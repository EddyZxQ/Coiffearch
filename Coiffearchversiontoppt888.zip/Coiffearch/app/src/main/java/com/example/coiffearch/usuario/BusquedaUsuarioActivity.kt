package com.example.coiffearch.usuario

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.SearchView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.coiffearch.R
import com.example.coiffearch.citasadptador.Cita
import com.example.coiffearch.citasadptador.RecyclerCitas
import com.example.coiffearch.databinding.ActivityBusquedaUsuarioBinding
import com.example.coiffearch.establecimientoadaptador.Establecimiento
import com.example.coiffearch.establecimientoadaptador.RecyclerEstablecimientos
import com.google.firebase.Timestamp
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class BusquedaUsuarioActivity : AppCompatActivity(), RecyclerEstablecimientos.OnCajaClickListener {

    private lateinit var binding: ActivityBusquedaUsuarioBinding

    lateinit var  recycler:RecyclerView
    var listaEstablecimientos: MutableList<Establecimiento> = mutableListOf()
    var listafiltroEstablecimientos: MutableList<Establecimiento> = mutableListOf()
    private var db = Firebase.firestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBusquedaUsuarioBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db.collection("establecimiento").get().addOnSuccessListener { resultado ->

            for (documento in resultado){

                listaEstablecimientos.add(
                    Establecimiento(
                        documento.data["nombre"].toString(),
                        documento.data["ubicacion"].toString(),
                        documento.data["aperturaHora"].toString()+"/"+documento.data["cierreHora"].toString(),
                        if (documento.data["estaAbierto"] as Boolean)"Abierto" else "Cerrado",
                        documento.data["establecimientoId"].toString())
                )


            }

            listafiltroEstablecimientos.addAll(listaEstablecimientos)

            setUp()
        }

        binding.buscador.setOnQueryTextListener(object :SearchView.OnQueryTextListener{
            override fun onQueryTextSubmit(p0: String?): Boolean {
                return true
            }

            override fun onQueryTextChange(nuevotexto: String?): Boolean {

                if (nuevotexto!!.isNotEmpty()){
                    listafiltroEstablecimientos.clear()
                    val busqueda = nuevotexto.lowercase()
                    listaEstablecimientos.forEach {
                        if (it.nombre.lowercase().contains(busqueda)){
                            listafiltroEstablecimientos.add(it)
                        }
                    }

                    recycler.adapter!!.notifyDataSetChanged()

                }else{
                    listafiltroEstablecimientos.clear()
                    listafiltroEstablecimientos.addAll(listaEstablecimientos)
                    recycler.adapter!!.notifyDataSetChanged()
                }

                return true
            }

        })


        binding.btnAtrasB.setOnClickListener { irMain() }


    }


    private fun setUp(){
        recycler = findViewById(R.id.listaEstablecimientos)
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = RecyclerEstablecimientos(this, listafiltroEstablecimientos,this)
    }

    override fun onItemClick(idEstab: String) {
        var intento = Intent(this@BusquedaUsuarioActivity, EstablecimientoActivity::class.java)
        intento.putExtra("idEstablecimiento",idEstab)
        startActivity(intento)
        finish()
    }

    fun irMain(){
        startActivity(Intent(this, PanelUsuarioActivity::class.java))
        finish()
    }

    override fun onBackPressed() { irMain() }


}