package com.example.coiffearch.favadaptador

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.coiffearch.R

class RecyclerFav(var context: Context, var establecimientosFavoritos: MutableList<EstabFav>, private var itemClickListener: OnBotonesClickListener):
    RecyclerView.Adapter<RecyclerFav.MiHolder>(){


    interface OnBotonesClickListener{
        fun onEliminarClick(idEstab:String)
        fun onCartaClick(idEstab:String)
    }

    inner class MiHolder(itemView: View):RecyclerView.ViewHolder(itemView){
        var nEstab: TextView
        var nEstado: TextView
        var nLugar: TextView
        var nHorario:TextView
        var btnEliminar: TextView



        fun bind(position: Int) {
            btnEliminar = itemView.findViewById(R.id.btnEliminarListaFav)


            //Toda LA CARD
            //itemView.setOnClickListener { itemClickListener.onCartaClick(establecimientosFavoritos[position].idEstab) }

            btnEliminar.setOnClickListener {
                itemClickListener.onEliminarClick(establecimientosFavoritos[position].idEstab)
            }
        }

        init {
            nEstab = itemView.findViewById(R.id.nEstab)
            nEstado = itemView.findViewById(R.id.nEstado)
            nLugar = itemView.findViewById(R.id.nLugar)
            nHorario = itemView.findViewById(R.id.nHorario)
            btnEliminar = itemView.findViewById(R.id.btnEliminarListaFav)

            // btnEliminar.setOnClickListener { Toast.makeText(context, "$campoAccion", Toast.LENGTH_LONG).show() }

        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MiHolder {
       var itemView = LayoutInflater.from(context).inflate(R.layout.estabfav_item, parent, false)
        return MiHolder(itemView)
    }

    override fun onBindViewHolder(holder: MiHolder, position: Int) {
        var estab =establecimientosFavoritos[position]
        holder.nEstab.text = estab.nombreEstab
        holder.nEstado.text = estab.estado
        holder.nHorario.text = estab.horario
        holder.nLugar.text = estab.lugar
        holder.bind(position)
    }

    override fun getItemCount(): Int {
        return  establecimientosFavoritos.size
    }
}