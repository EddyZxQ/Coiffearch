package com.example.coiffearch

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.coiffearch.databinding.ActivityLoginBinding
import com.example.coiffearch.empresa.PanelEmpresaActivity
import com.example.coiffearch.usuario.PanelUsuarioActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding

    private lateinit var auth: FirebaseAuth

    private val db = Firebase.firestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)
        this.supportActionBar?.hide()

        auth = Firebase.auth

        binding.btnIniciarSesion.setOnClickListener {
            iniciarSesion(binding.campoEmail.text.toString(), binding.campoPass.text.toString())
        }


        binding.noTengoCuenta.setOnClickListener {
            startActivity(Intent(this@LoginActivity,RegisterActivity::class.java))
            finish()
        }


    }

    public override fun onStart() {
        super.onStart()
        val currentUser = auth.currentUser
        if(currentUser != null) {

            db.collection("usuarios").document(auth.currentUser?.uid.toString()).get().addOnSuccessListener {
                if (it["tipoCuenta"].toString() == "0"){
                    irPanelUsuario()
                }else if(it["tipoCuenta"].toString() == "1"){
                    irPanelEmpresa()
                }
            }


        }

    }


    private fun irPanelUsuario(){
        startActivity(Intent(this@LoginActivity, PanelUsuarioActivity::class.java))
        finish()
    }

    private fun irPanelEmpresa(){
        startActivity(Intent(this@LoginActivity, PanelEmpresaActivity::class.java))
        finish()
    }


    private fun iniciarSesion(email:String, password:String){
        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    db.collection("usuarios").get().addOnSuccessListener { resultado ->
                        for (documento in resultado){
                            if (email == documento.data["email"].toString()){

                                if (documento.data["tipoCuenta"].toString() == "0"){
                                    irPanelUsuario()

                                }else if (documento.data["tipoCuenta"].toString() == "1"){
                                    irPanelEmpresa()

                                }else{
                                    Toast.makeText(this,"Error database",Toast.LENGTH_SHORT).show()
                                }
                            }

                        }
                    }

                    //Fin
                } else {
                    Toast.makeText(this,"Error contraseña o email incorrectos",Toast.LENGTH_SHORT).show()
                }
            }
    }
}