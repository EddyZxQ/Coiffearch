package com.example.coiffearch.adaptadorlocales

import com.example.coiffearch.R



import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.coiffearch.empresa.VerLocalesActivity
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase


class RecyclerLocal(private val context: Context,
                       val locales: MutableList<Local>,
                       private var itemClickListener: OnBotonesClickListener2
): RecyclerView.Adapter<RecyclerLocal.MiHolder>() {

    interface OnBotonesClickListener2{
        fun onEliminarClick(idEstab:String)
        fun onCartaClick(idEstab:String)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MiHolder {
        val itemView= LayoutInflater.from(context).inflate(R.layout.card_local,parent,false)
        return MiHolder(itemView)

    }

    override fun onBindViewHolder(holder: MiHolder, position: Int) {
        val loc= locales[position]
        holder.idNombre.setText(loc.nombreLocal)
        holder.bind(position)
    }

    override fun getItemCount(): Int {
        return locales.size
    }


    inner class MiHolder(itemView: View): RecyclerView.ViewHolder(itemView){


        var imgLocal: ImageView
        var idNombre: TextView



        init {

            imgLocal= itemView.findViewById(R.id.imgCasa)
            idNombre = itemView.findViewById(R.id.idNombreLocal)


        }

        fun bind(position: Int){

            var eliminar: ImageButton = itemView.findViewById(R.id.imgBorrar)


            itemView.setOnClickListener {
                itemClickListener.onCartaClick(locales[position].id)
            }


            eliminar.setOnClickListener {
                itemClickListener.onEliminarClick((locales[position].id))
            }

            Glide.with(context).load(locales[position].imgUrl[0]).into(imgLocal)


        }

    }
}