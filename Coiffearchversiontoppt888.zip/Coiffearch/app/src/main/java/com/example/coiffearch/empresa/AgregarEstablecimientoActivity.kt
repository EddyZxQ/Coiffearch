package com.example.coiffearch.empresa

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import com.example.coiffearch.R
import com.example.coiffearch.databinding.ActivityAgregarEstablecimientoBinding
import com.example.coiffearch.databinding.ActivityEstablecimientoBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import com.google.firebase.storage.ktx.storage
import java.util.*

class AgregarEstablecimientoActivity : AppCompatActivity() {

    private lateinit var binding:ActivityAgregarEstablecimientoBinding
    private  var db = Firebase.firestore
    private lateinit var auth: FirebaseAuth
    private  var listaServicios: MutableList<String> = mutableListOf()
    private  var listaFotosExposicion: MutableList<String> = mutableListOf()
    private  var numFotos = ""
    private var idEstab =UUID.randomUUID().toString()

    lateinit var storage: FirebaseStorage
    private val responseLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()){ activityResult ->
        if (activityResult.resultCode == RESULT_OK ) {
            val clipData = activityResult.data?.clipData
            if (clipData != null){
                numFotos = (clipData.itemCount).toString()
                for (i in 0 until clipData.itemCount) {
                    val uri = clipData.getItemAt(i).uri
                    uri?.let { fileUpload(it) }
                }
            }else {
                numFotos = "1"
                val uri = activityResult.data?.data
                uri?.let { fileUpload(it) }
            }
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAgregarEstablecimientoBinding .inflate(layoutInflater)
        setContentView(binding.root)

        auth = Firebase.auth

        binding.btnAgregarServicio.setOnClickListener {
            if (binding.cServiciosLocal.text.toString().isNotEmpty()){
                listaServicios.add(binding.cServiciosLocal.text.toString())
                binding.cServiciosLocal.text.clear()
            }
        }

        binding.btnVerServiciosAgregados.setOnClickListener {
           if (listaServicios.isNotEmpty()) popUpServicios() else Toast.makeText(this,"No hay ningun servicio en la lista",Toast.LENGTH_SHORT).show()
        }


        binding.btnCrearLocal.setOnClickListener { crearLocal() }
        binding.btnAtrasPU.setOnClickListener { irAtras() }
        binding.btnAgregarFotosLocal.setOnClickListener { fileManager() }




    }

    override fun onBackPressed() {
        irAtras()
    }

    private fun irAtras(){
        startActivity(Intent(this@AgregarEstablecimientoActivity, VerLocalesActivity::class.java))
        finish()
    }

    private fun popUpServicios(){

        var listaServiciox : ListView = ListView(this)
        /*
        var servicios = ""
        for (i in listaServicios) servicios = i+"\n"
        val builder = AlertDialog.Builder(this)
        builder.setMessage(servicios).setTitle("Servicios Agregados")
        val dialog: AlertDialog = builder.create()
        dialog.show()
        */

        val adaptador = ArrayAdapter(this,android.R.layout.simple_list_item_1,listaServicios)
        listaServiciox.adapter = adaptador



        val builder = AlertDialog.Builder(this)

        builder.setView(listaServiciox)
        builder.setTitle("Lista De Servicios").setMessage("Pulsa para eliminar")
        builder.setNeutralButton("Cerrar",{_,_ -> null})
        val dialog: AlertDialog = builder.create()
        dialog.show()


        listaServiciox.setOnItemClickListener { adapterView: AdapterView<*>, view1: View, pos:Int,
                                                id: Long ->
            val servicio = adaptador.getItem(pos) as String
            listaServicios.remove(servicio)
            dialog.hide()

            popUpServicios()
        }

    }


    private fun crearLocal(){

        var idPropietario = auth.currentUser?.uid.toString()
        var nombre = binding.cNombreLocal.text.toString()
        var descripcion = binding.cDescripcionLocal.text.toString()
        var ubicacion = binding.cUbiLocal.text.toString()
        var publico = binding.cPublicoLocal.text.toString()
        var horaApertura = binding.cHoraAperturaLocal.text.toString()
        var horaCierre = binding.cHoraCierreLocal.text.toString()



        var datos = mapOf(
            "idPropietario" to idPropietario,
            "nombre" to nombre,
            "ubicacion" to ubicacion,
            "servico" to listaServicios,
            "imagenesExposicion" to listaFotosExposicion.toSet().toMutableList(),
            "publico" to publico,
            "aperturaHora" to horaApertura,
            "cierreHora" to horaCierre,
            "descripcion" to descripcion,
            "diasCierre" to FieldValue.arrayUnion(),
            "diasCierreEspecial" to FieldValue.arrayUnion(),
            "estaAbierto" to false,
            "establecimientoId" to idEstab
        )




        db.collection("establecimiento").document(idEstab.toString()).set(datos).addOnSuccessListener {
            Toast.makeText(this,"LOCAL AGREGADO EXITOSAMENTE",Toast.LENGTH_SHORT).show()
            irAtras()
        }

    }


    private fun fileManager(){
        storage = Firebase.storage

        val intent = Intent(Intent.ACTION_GET_CONTENT)
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN_MR2) {
            intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        intent.type = "*/*"

        responseLauncher.launch(intent)
    }

    private fun fileUpload(mUri: Uri) {
        val folder: StorageReference = FirebaseStorage.getInstance().reference.child("User")
        val path =mUri.lastPathSegment.toString()
        val fileName: StorageReference = folder.child(path.substring(path.lastIndexOf('/')+1))

        fileName.putFile(mUri).addOnSuccessListener {
            fileName.downloadUrl.addOnSuccessListener { uri ->
                for (i in 0 until numFotos.toInt()){
                    listaFotosExposicion.add(uri.toString())
                }

            }
        }.addOnFailureListener {}
    }



}