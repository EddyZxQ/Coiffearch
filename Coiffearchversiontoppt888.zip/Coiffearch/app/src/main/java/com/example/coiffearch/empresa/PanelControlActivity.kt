package com.example.coiffearch.empresa

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.coiffearch.databinding.ActivityPanelControlBinding

class PanelControlActivity : AppCompatActivity() {
    private  lateinit var binding: ActivityPanelControlBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPanelControlBinding.inflate(layoutInflater)
        setContentView(binding.root)




    }
}